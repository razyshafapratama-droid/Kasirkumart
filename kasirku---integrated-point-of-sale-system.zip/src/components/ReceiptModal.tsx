import React, { useState } from 'react';
import { Printer, Copy, Check, Plus, X, Download } from 'lucide-react';
import { StoreSettings, Transaction } from '../types';
import { formatDate, formatRupiah, formatTime } from '../utils/formatters';

interface ReceiptModalProps {
  isOpen: boolean;
  transaction: Transaction | null;
  storeSettings: StoreSettings;
  onClose: () => void;
  onNewTransaction: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  isOpen,
  transaction,
  storeSettings,
  onClose,
  onNewTransaction,
}) => {
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen || !transaction) return null;

  const handlePrint = () => {
    window.print();
  };

  const generateReceiptPlainText = () => {
    const divider = '--------------------------------';
    let text = `${storeSettings.storeName.toUpperCase()}\n`;
    text += `${storeSettings.tagline}\n`;
    text += `${storeSettings.address}\n`;
    text += `Telp: ${storeSettings.phone}\n`;
    text += `${divider}\n`;
    text += `No. Nota : ${transaction.invoiceNumber}\n`;
    text += `Waktu    : ${formatDate(transaction.timestamp)}\n`;
    text += `Kasir    : ${transaction.cashierName}\n`;
    text += `${divider}\n`;

    transaction.items.forEach((item) => {
      text += `${item.name}\n`;
      text += `  ${item.quantity} x ${formatRupiah(item.price)} = ${formatRupiah(item.subtotal)}\n`;
    });

    text += `${divider}\n`;
    text += `Subtotal  : ${formatRupiah(transaction.subtotal)}\n`;
    if (transaction.discount > 0) {
      text += `Diskon    : -${formatRupiah(transaction.discount)}\n`;
    }
    if (transaction.tax > 0) {
      text += `PPN       : ${formatRupiah(transaction.tax)}\n`;
    }
    text += `TOTAL     : ${formatRupiah(transaction.total)}\n`;
    text += `Bayar (${transaction.paymentMethod}) : ${formatRupiah(transaction.amountPaid)}\n`;
    text += `Kembali   : ${formatRupiah(transaction.change)}\n`;
    text += `${divider}\n`;
    text += `${storeSettings.receiptFooterMessage}\n`;
    return text;
  };

  const handleCopyText = () => {
    const text = generateReceiptPlainText();
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadText = () => {
    const text = generateReceiptPlainText();
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Struk-${transaction.invoiceNumber}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200 flex flex-col max-h-[92vh]">
        {/* Modal Action Bar */}
        <div className="bg-slate-900 text-white p-3.5 px-4 flex items-center justify-between no-print">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            <h3 className="font-bold text-sm text-white">Struk Transaksi Selesai</h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Receipt Preview (Thermal Paper Style) */}
        <div className="p-4 sm:p-6 overflow-y-auto bg-slate-100/60 flex-1 flex justify-center">
          <div
            id="thermal-receipt"
            className="w-full max-w-[340px] bg-white p-5 rounded-lg shadow-sm border border-slate-200 text-slate-800 font-mono text-xs select-text leading-relaxed"
          >
            {/* Header / Store Info */}
            <div className="text-center pb-3 border-b border-dashed border-slate-400">
              <h2 className="font-extrabold text-base tracking-tight text-slate-950">
                {storeSettings.storeName.toUpperCase()}
              </h2>
              <p className="text-[11px] text-slate-600 mt-0.5">{storeSettings.tagline}</p>
              <p className="text-[10px] text-slate-500 mt-1">{storeSettings.address}</p>
              <p className="text-[10px] text-slate-500">Telp: {storeSettings.phone}</p>
            </div>

            {/* Meta info */}
            <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span>No. Nota:</span>
                <span className="font-bold">{transaction.invoiceNumber}</span>
              </div>
              <div className="flex justify-between">
                <span>Tanggal:</span>
                <span>{formatDate(transaction.timestamp)}</span>
              </div>
              <div className="flex justify-between">
                <span>Kasir:</span>
                <span>{transaction.cashierName}</span>
              </div>
            </div>

            {/* Items */}
            <div className="py-2.5 border-b border-dashed border-slate-400 space-y-2">
              {transaction.items.map((item, idx) => (
                <div key={idx} className="space-y-0.5">
                  <div className="font-bold text-slate-900">{item.name}</div>
                  <div className="flex justify-between text-slate-600">
                    <span>
                      {item.quantity} x {formatRupiah(item.price)}
                    </span>
                    <span className="font-semibold text-slate-900">
                      {formatRupiah(item.subtotal)}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Calculations */}
            <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>{formatRupiah(transaction.subtotal)}</span>
              </div>
              {transaction.discount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>Diskon</span>
                  <span>-{formatRupiah(transaction.discount)}</span>
                </div>
              )}
              {transaction.tax > 0 && (
                <div className="flex justify-between">
                  <span>PPN</span>
                  <span>{formatRupiah(transaction.tax)}</span>
                </div>
              )}
              <div className="flex justify-between font-black text-sm pt-1 border-t border-dotted border-slate-300 text-slate-950">
                <span>TOTAL</span>
                <span>{formatRupiah(transaction.total)}</span>
              </div>
              <div className="flex justify-between pt-1">
                <span>Bayar ({transaction.paymentMethod})</span>
                <span>{formatRupiah(transaction.amountPaid)}</span>
              </div>
              <div className="flex justify-between font-bold text-slate-950">
                <span>KEMBALI</span>
                <span>{formatRupiah(transaction.change)}</span>
              </div>
            </div>

            {/* Footer */}
            <div className="pt-3 text-center text-[10px] text-slate-500 whitespace-pre-line leading-normal">
              {storeSettings.receiptFooterMessage}
            </div>
          </div>
        </div>

        {/* Modal Buttons (Thermal Print, Copy, New Sale) */}
        <div className="p-4 bg-white border-t border-slate-200 space-y-2 no-print">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handlePrint}
              className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-sm transition-colors"
            >
              <Printer className="w-4 h-4 text-emerald-400" />
              <span>Cetak Printer (Thermal)</span>
            </button>

            <button
              onClick={handleCopyText}
              className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer border border-slate-200 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700">Tersalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-slate-600" />
                  <span>Salin Struk (WA)</span>
                </>
              )}
            </button>
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleDownloadText}
              className="py-2 px-3 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 font-semibold text-xs flex items-center justify-center gap-1.5 border border-slate-200 transition-colors cursor-pointer"
              title="Unduh file .txt struk"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Simpan TXT</span>
            </button>

            <button
              onClick={onNewTransaction}
              className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer transition-colors"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Transaksi Baru</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
