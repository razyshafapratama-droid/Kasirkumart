import React, { useState } from 'react';
import { X, ShieldCheck, User, KeyRound, Check, Lock } from 'lucide-react';
import { UserAccount } from '../types';

interface RoleLoginModalProps {
  isOpen: boolean;
  currentUser: UserAccount;
  allUsers: UserAccount[];
  onClose: () => void;
  onSelectUser: (user: UserAccount) => void;
}

export const RoleLoginModal: React.FC<RoleLoginModalProps> = ({
  isOpen,
  currentUser,
  allUsers,
  onClose,
  onSelectUser,
}) => {
  const [selectedUser, setSelectedUser] = useState<UserAccount>(currentUser);
  const [enteredPin, setEnteredPin] = useState<string>('');
  const [pinError, setPinError] = useState<string>('');

  if (!isOpen) return null;

  const handleUserSelect = (user: UserAccount) => {
    setSelectedUser(user);
    setEnteredPin('');
    setPinError('');
  };

  const handleLoginConfirm = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    // Verify PIN if entered, or allow quick switch with helper
    if (enteredPin && enteredPin !== selectedUser.pin) {
      setPinError(`PIN salah! (Hint: PIN default ${selectedUser.name.includes('Admin') ? '1234' : '0000'})`);
      return;
    }

    onSelectUser(selectedUser);
    onClose();
  };

  const handleQuickSwitch = (user: UserAccount) => {
    onSelectUser(user);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-sm sm:text-base">Ganti Peran / Login Kasir</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <p className="text-xs text-slate-500">
            Pilih akun pengguna. Hak akses disesuaikan: Admin memiliki wewenang penuh pada produk, stok, dan laporan laba.
          </p>

          {/* User List */}
          <div className="space-y-2">
            {allUsers.map((user) => {
              const isSelected = selectedUser.id === user.id;
              const isCurrent = currentUser.id === user.id;
              return (
                <div
                  key={user.id}
                  onClick={() => handleUserSelect(user)}
                  className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                    isSelected
                      ? 'border-emerald-600 bg-emerald-50/70 ring-1 ring-emerald-500'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl ${user.avatarBg} text-white flex items-center justify-center font-bold text-xs`}
                    >
                      {user.role === 'admin' ? (
                        <ShieldCheck className="w-5 h-5" />
                      ) : (
                        <User className="w-5 h-5" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-900 text-xs sm:text-sm">
                          {user.name}
                        </span>
                        {isCurrent && (
                          <span className="text-[10px] bg-slate-200 text-slate-700 px-1.5 py-0.2 rounded font-semibold">
                            Aktif
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-500 block uppercase tracking-wider font-semibold">
                        {user.role === 'admin' ? 'Akses Penuh (Admin)' : 'Kasir Penjualan'}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleQuickSwitch(user);
                    }}
                    className="text-xs font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-100 hover:bg-emerald-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                  >
                    Masuk
                  </button>
                </div>
              );
            })}
          </div>

          {/* PIN Input (Optional Security) */}
          <form onSubmit={handleLoginConfirm} className="pt-2 border-t border-slate-100 space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                PIN Akses (PIN {selectedUser.role === 'admin' ? '1234' : '0000'})
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="password"
                  maxLength={6}
                  placeholder={`Masukkan PIN ${selectedUser.name}`}
                  value={enteredPin}
                  onChange={(e) => {
                    setEnteredPin(e.target.value);
                    setPinError('');
                  }}
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-xl focus:outline-none focus:border-emerald-600 font-mono tracking-widest"
                />
              </div>
              {pinError && <p className="text-[11px] text-rose-600 mt-1 font-semibold">{pinError}</p>}
            </div>

            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer shadow-md shadow-emerald-600/20"
              >
                Konfirmasi Masuk
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
