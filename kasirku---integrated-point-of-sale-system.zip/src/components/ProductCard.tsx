import React, { useState } from 'react';
import { Package, Coffee, CupSoda, Utensils, ShoppingBag, Sparkles, Box, Plus, Check, ImageOff } from 'lucide-react';
import { Product } from '../types';
import { formatRupiah } from '../utils/formatters';

interface ProductCardProps {
  product: Product;
  cartQuantity: number;
  onAddToCart: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  cartQuantity,
  onAddToCart,
}) => {
  const [imageError, setImageError] = useState(false);
  const isOutOfStock = product.stock <= 0;
  const isLowStock = product.stock > 0 && product.stock <= 5;

  // Fallback icon based on category/icon field
  const renderIcon = () => {
    const iconType = product.icon || '';
    const cat = product.category.toLowerCase();

    if (iconType === 'cup' || cat.includes('minum')) {
      return <CupSoda className="w-7 h-7 text-slate-700" />;
    }
    if (iconType === 'coffee' || cat.includes('kopi')) {
      return <Coffee className="w-7 h-7 text-slate-700" />;
    }
    if (iconType === 'box' || cat.includes('snack')) {
      return <Box className="w-7 h-7 text-slate-700" />;
    }
    if (iconType === 'sparkles' || cat.includes('kebutuhan')) {
      return <Sparkles className="w-7 h-7 text-slate-700" />;
    }
    if (iconType === 'shopping-bag' || cat.includes('sembako')) {
      return <ShoppingBag className="w-7 h-7 text-slate-700" />;
    }
    if (iconType === 'utensils') {
      return <Utensils className="w-7 h-7 text-slate-700" />;
    }
    return <Package className="w-7 h-7 text-slate-700" />;
  };

  return (
    <div
      onClick={() => {
        if (!isOutOfStock) onAddToCart(product);
      }}
      className={`group relative bg-white rounded-2xl p-3 sm:p-4 border transition-all duration-200 select-none flex flex-col justify-between cursor-pointer ${
        isOutOfStock
          ? 'opacity-60 bg-slate-50 border-slate-200 cursor-not-allowed'
          : 'border-slate-200 hover:border-emerald-500 hover:shadow-lg hover:-translate-y-0.5'
      } ${cartQuantity > 0 ? 'ring-2 ring-emerald-500/80 border-transparent shadow-sm' : ''}`}
    >
      {/* Badge if in cart */}
      {cartQuantity > 0 && (
        <span className="absolute -top-2.5 -right-2 bg-emerald-600 text-white font-black text-xs px-2.5 py-0.5 rounded-full shadow-md flex items-center gap-1 z-20 animate-in fade-in zoom-in-75">
          <Check className="w-3 h-3 stroke-[3]" />
          {cartQuantity}x
        </span>
      )}

      <div>
        {/* Product Image Frame */}
        <div className="w-full h-28 sm:h-32 rounded-xl bg-slate-100 overflow-hidden mb-3 relative flex items-center justify-center border border-slate-100 group-hover:border-slate-200 transition-colors">
          {product.image && !imageError ? (
            <img
              src={product.image}
              alt={product.name}
              onError={() => setImageError(true)}
              loading="lazy"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="p-3 bg-white rounded-xl shadow-xs border border-slate-200/60 group-hover:scale-105 transition-transform">
              {renderIcon()}
            </div>
          )}

          {/* Category Chip tag over image */}
          <span className="absolute top-2 left-2 px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-900/70 text-white backdrop-blur-xs shadow-xs">
            {product.category}
          </span>
        </div>

        {/* Product Name */}
        <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug line-clamp-1 group-hover:text-emerald-700 transition-colors">
          {product.name}
        </h3>

        {/* Price */}
        <p className="font-extrabold text-slate-950 text-base sm:text-lg mt-1 font-['Plus_Jakarta_Sans']">
          {formatRupiah(product.price)}
        </p>

        {/* Stock status indicator */}
        <div className="flex items-center justify-between gap-1 text-xs text-slate-500 mt-1">
          <span className="text-[11px] font-mono text-slate-400 truncate">
            {product.unit}
          </span>
          <span
            className={`font-semibold text-[11px] px-2 py-0.5 rounded ${
              isOutOfStock
                ? 'bg-rose-100 text-rose-700 font-bold'
                : isLowStock
                ? 'bg-amber-100 text-amber-800 font-bold'
                : 'bg-emerald-50 text-emerald-800'
            }`}
          >
            {isOutOfStock ? 'Habis (0)' : `Stok: ${product.stock}`}
          </span>
        </div>
      </div>

      {/* Button: + Tambah */}
      <button
        disabled={isOutOfStock}
        onClick={(e) => {
          e.stopPropagation();
          if (!isOutOfStock) onAddToCart(product);
        }}
        className={`w-full mt-3.5 py-2 px-3 rounded-full text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer ${
          isOutOfStock
            ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
            : cartQuantity > 0
            ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
            : 'bg-slate-900 hover:bg-slate-800 text-white'
        }`}
      >
        <Plus className="w-4 h-4 stroke-[2.5]" />
        <span>{cartQuantity > 0 ? 'Tambah Lagi' : 'Tambah'}</span>
      </button>
    </div>
  );
};
