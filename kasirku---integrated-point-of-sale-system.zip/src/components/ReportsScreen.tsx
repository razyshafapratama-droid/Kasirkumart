import React, { useState, useMemo } from 'react';
import { BarChart3, TrendingUp, Calendar, Download, DollarSign, Receipt, Package, Award, ArrowUpRight, ShieldCheck, Printer } from 'lucide-react';
import { Product, Transaction, UserRole } from '../types';
import { formatRupiah, formatDate } from '../utils/formatters';

interface ReportsScreenProps {
  transactions: Transaction[];
  products: Product[];
  userRole: UserRole;
  onViewTransactionDetail: (trx: Transaction) => void;
}

export const ReportsScreen: React.FC<ReportsScreenProps> = ({
  transactions,
  products,
  userRole,
  onViewTransactionDetail,
}) => {
  const [period, setPeriod] = useState<'today' | 'yesterday' | 'week' | 'month' | 'all'>('today');

  // Filter transactions by period
  const filteredTransactions = useMemo(() => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

    return transactions.filter((t) => {
      const txTime = new Date(t.timestamp).getTime();
      if (period === 'today') {
        return txTime >= todayStart;
      }
      if (period === 'yesterday') {
        const yesterdayStart = todayStart - 86400000;
        return txTime >= yesterdayStart && txTime < todayStart;
      }
      if (period === 'week') {
        const weekAgo = todayStart - 7 * 86400000;
        return txTime >= weekAgo;
      }
      if (period === 'month') {
        const monthAgo = todayStart - 30 * 86400000;
        return txTime >= monthAgo;
      }
      return true;
    });
  }, [transactions, period]);

  // Aggregate Metrics
  const totalOmzet = useMemo(() => {
    return filteredTransactions.reduce((acc, t) => acc + (t.total || 0), 0);
  }, [filteredTransactions]);

  const totalTransactionsCount = filteredTransactions.length;

  const totalItemsSold = useMemo(() => {
    return filteredTransactions.reduce((acc, t) => {
      return acc + t.items.reduce((sum, item) => sum + item.quantity, 0);
    }, 0);
  }, [filteredTransactions]);

  const averageBasket = totalTransactionsCount > 0 ? Math.round(totalOmzet / totalTransactionsCount) : 0;

  // Profit calculation (Omzet - Cost)
  const totalProfit = useMemo(() => {
    return filteredTransactions.reduce((acc, t) => {
      const costForTx = t.items.reduce((sum, item) => {
        const itemCost = item.cost || Math.round(item.price * 0.75);
        return sum + itemCost * item.quantity;
      }, 0);
      return acc + (t.total - costForTx);
    }, 0);
  }, [filteredTransactions]);

  // Top Selling Products calculation
  const topProducts = useMemo(() => {
    const map: Record<string, { name: string; quantity: number; revenue: number }> = {};
    filteredTransactions.forEach((t) => {
      t.items.forEach((item) => {
        if (!map[item.productId]) {
          map[item.productId] = { name: item.name, quantity: 0, revenue: 0 };
        }
        map[item.productId].quantity += item.quantity;
        map[item.productId].revenue += item.subtotal;
      });
    });

    return Object.values(map)
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 5);
  }, [filteredTransactions]);

  const maxSoldQty = topProducts.length > 0 ? topProducts[0].quantity : 1;

  // Payment Method Breakdown
  const paymentBreakdown = useMemo(() => {
    const counts = { TUNAI: 0, QRIS: 0, TRANSFER: 0 };
    const amounts = { TUNAI: 0, QRIS: 0, TRANSFER: 0 };

    filteredTransactions.forEach((t) => {
      counts[t.paymentMethod] = (counts[t.paymentMethod] || 0) + 1;
      amounts[t.paymentMethod] = (amounts[t.paymentMethod] || 0) + t.total;
    });

    return { counts, amounts };
  }, [filteredTransactions]);

  // Export to CSV
  const handleExportCSV = () => {
    if (filteredTransactions.length === 0) return;

    const headers = ['No Nota', 'Waktu', 'Kasir', 'Metode Bayar', 'Total Belanja (Rp)', 'Jumlah Item'];
    const rows = filteredTransactions.map((t) => [
      t.invoiceNumber,
      `"${formatDate(t.timestamp)}"`,
      `"${t.cashierName}"`,
      t.paymentMethod,
      t.total,
      t.items.reduce((sum, i) => sum + i.quantity, 0),
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Laporan-Penjualan-${period}-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner and Filter Pills */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900">Laporan Penjualan & Omzet</h2>
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
              Otomatis & Terpusat
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Analisis performa omzet penjualan, laba kotor, dan komparasi produk terlaris.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Period selector */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-bold text-slate-700">
            <button
              onClick={() => setPeriod('today')}
              className={`px-3 py-1.5 rounded-lg cursor-pointer transition-colors ${
                period === 'today' ? 'bg-white shadow-xs text-emerald-700' : 'hover:text-slate-900'
              }`}
            >
              Hari Ini
            </button>
            <button
              onClick={() => setPeriod('yesterday')}
              className={`px-3 py-1.5 rounded-lg cursor-pointer transition-colors ${
                period === 'yesterday' ? 'bg-white shadow-xs text-emerald-700' : 'hover:text-slate-900'
              }`}
            >
              Kemarin
            </button>
            <button
              onClick={() => setPeriod('week')}
              className={`px-3 py-1.5 rounded-lg cursor-pointer transition-colors ${
                period === 'week' ? 'bg-white shadow-xs text-emerald-700' : 'hover:text-slate-900'
              }`}
            >
              7 Hari
            </button>
            <button
              onClick={() => setPeriod('month')}
              className={`px-3 py-1.5 rounded-lg cursor-pointer transition-colors ${
                period === 'month' ? 'bg-white shadow-xs text-emerald-700' : 'hover:text-slate-900'
              }`}
            >
              30 Hari
            </button>
            <button
              onClick={() => setPeriod('all')}
              className={`px-3 py-1.5 rounded-lg cursor-pointer transition-colors ${
                period === 'all' ? 'bg-white shadow-xs text-emerald-700' : 'hover:text-slate-900'
              }`}
            >
              Semua
            </button>
          </div>

          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-colors"
            title="Download CSV Laporan"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Ekspor CSV</span>
          </button>
        </div>
      </div>

      {/* 4 Performance Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Omzet */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Total Omzet
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <p className="text-2xl font-black text-slate-950 font-['Plus_Jakarta_Sans']">
              {formatRupiah(totalOmzet)}
            </p>
            <p className="text-xs text-emerald-600 font-semibold mt-1">
              {totalTransactionsCount} Transaksi Selesai
            </p>
          </div>
        </div>

        {/* Total Transaksi */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Barang Terjual
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <p className="text-2xl font-black text-slate-950 font-['Plus_Jakarta_Sans']">
              {totalItemsSold} <span className="text-sm font-semibold text-slate-500">unit</span>
            </p>
            <p className="text-xs text-blue-600 font-semibold mt-1">
              Dari {products.length} varian produk
            </p>
          </div>
        </div>

        {/* Laba Kotor / Keuntungan (Admin view) */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Estimasi Laba Bersih
            </span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            {userRole === 'admin' ? (
              <>
                <p className="text-2xl font-black text-purple-700 font-['Plus_Jakarta_Sans']">
                  {formatRupiah(totalProfit)}
                </p>
                <p className="text-xs text-purple-600 font-semibold mt-1">
                  Margin: {totalOmzet > 0 ? Math.round((totalProfit / totalOmzet) * 100) : 0}%
                </p>
              </>
            ) : (
              <div className="text-xs text-slate-400 py-1 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                <span>Khusus Akses Admin</span>
              </div>
            )}
          </div>
        </div>

        {/* Rata-rata per transaksi */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Rata-rata Nota
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <p className="text-2xl font-black text-slate-950 font-['Plus_Jakarta_Sans']">
              {formatRupiah(averageBasket)}
            </p>
            <p className="text-xs text-amber-600 font-semibold mt-1">
              Rerata per pelanggan
            </p>
          </div>
        </div>
      </div>

      {/* Middle Row: Top Products & Payment Methods Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top 5 Best Sellers */}
        <div className="lg:col-span-2 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-500" />
              <h3 className="font-bold text-slate-900 text-base">Produk Terlaris (Top Selling)</h3>
            </div>
            <span className="text-xs text-slate-400">Berdasarkan unit terjual</span>
          </div>

          {topProducts.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-8">Belum ada data penjualan pada periode ini.</p>
          ) : (
            <div className="space-y-3.5">
              {topProducts.map((p, idx) => {
                const percentage = Math.round((p.quantity / maxSoldQty) * 100);
                return (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between text-xs sm:text-sm">
                      <div className="flex items-center gap-2">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${
                          idx === 0 ? 'bg-amber-100 text-amber-800' : idx === 1 ? 'bg-slate-200 text-slate-700' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {idx + 1}
                        </span>
                        <span className="font-bold text-slate-800">{p.name}</span>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-slate-900">{p.quantity} terjual</span>
                        <span className="text-xs text-slate-400 block">{formatRupiah(p.revenue)}</span>
                      </div>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Payment Methods */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-base mb-1">Metode Pembayaran</h3>
            <p className="text-xs text-slate-400 mb-4">Distribusi transaksi kasir</p>

            <div className="space-y-3">
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-900 block">Tunai (Cash)</span>
                  <span className="text-xs text-emerald-700">{paymentBreakdown.counts.TUNAI} Transaksi</span>
                </div>
                <span className="font-black text-sm text-emerald-950 font-['Plus_Jakarta_Sans']">
                  {formatRupiah(paymentBreakdown.amounts.TUNAI)}
                </span>
              </div>

              <div className="p-3 bg-indigo-50 rounded-xl border border-indigo-100 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-indigo-900 block">QRIS Instant</span>
                  <span className="text-xs text-indigo-700">{paymentBreakdown.counts.QRIS} Transaksi</span>
                </div>
                <span className="font-black text-sm text-indigo-950 font-['Plus_Jakarta_Sans']">
                  {formatRupiah(paymentBreakdown.amounts.QRIS)}
                </span>
              </div>

              <div className="p-3 bg-blue-50 rounded-xl border border-blue-100 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-blue-900 block">Transfer Bank</span>
                  <span className="text-xs text-blue-700">{paymentBreakdown.counts.TRANSFER} Transaksi</span>
                </div>
                <span className="font-black text-sm text-blue-950 font-['Plus_Jakarta_Sans']">
                  {formatRupiah(paymentBreakdown.amounts.TRANSFER)}
                </span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 text-xs text-slate-500 mt-4">
            Total seluruh penerimaan: <strong className="text-slate-800">{formatRupiah(totalOmzet)}</strong>
          </div>
        </div>
      </div>

      {/* Recent Sales in Period */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-sm sm:text-base">
            Riwayat Penjualan ({filteredTransactions.length} Transaksi)
          </h3>
          <span className="text-xs text-slate-500">Klik baris untuk melihat nota struk</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[11px] tracking-wider">
                <th className="py-3 px-4">No. Transaksi</th>
                <th className="py-3 px-4">Waktu</th>
                <th className="py-3 px-4">Kasir</th>
                <th className="py-3 px-4">Metode</th>
                <th className="py-3 px-4 text-right">Total Transaksi</th>
                <th className="py-3 px-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredTransactions.slice(0, 10).map((t) => (
                <tr
                  key={t.id}
                  onClick={() => onViewTransactionDetail(t)}
                  className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                >
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">
                    {t.invoiceNumber}
                  </td>
                  <td className="py-3 px-4 text-slate-500">
                    {formatDate(t.timestamp)}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-800">
                    {t.cashierName}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                        t.paymentMethod === 'TUNAI'
                          ? 'bg-emerald-100 text-emerald-800'
                          : t.paymentMethod === 'QRIS'
                          ? 'bg-indigo-100 text-indigo-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {t.paymentMethod}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-black text-slate-900 font-['Plus_Jakarta_Sans']">
                    {formatRupiah(t.total)}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onViewTransactionDetail(t);
                      }}
                      className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
                    >
                      Cetak Struk
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
