import React, { useState } from 'react';
import { Search, Printer, Calendar, ArrowRight, FileText, CheckCircle2 } from 'lucide-react';
import { Transaction } from '../types';
import { formatDate, formatRupiah } from '../utils/formatters';

interface TransactionHistoryViewProps {
  transactions: Transaction[];
  onSelectTransaction: (trx: Transaction) => void;
}

export const TransactionHistoryView: React.FC<TransactionHistoryViewProps> = ({
  transactions,
  onSelectTransaction,
}) => {
  const [search, setSearch] = useState('');
  const [selectedMethod, setSelectedMethod] = useState<string>('Semua');

  const filtered = transactions.filter((t) => {
    const matchSearch =
      t.invoiceNumber.toLowerCase().includes(search.toLowerCase()) ||
      t.cashierName.toLowerCase().includes(search.toLowerCase()) ||
      t.items.some((i) => i.name.toLowerCase().includes(search.toLowerCase()));

    const matchMethod = selectedMethod === 'Semua' || t.paymentMethod === selectedMethod;

    return matchSearch && matchMethod;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Riwayat Seluruh Transaksi</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Daftar lengkap nota penjualan kasir. Anda dapat memeriksa rincian belanja dan mencetak ulang bukti struk kapan saja.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-700 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200">
            Total {transactions.length} Transaksi Tercatat
          </span>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari no nota, nama kasir, atau produk belanja..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-600 focus:bg-white transition-colors"
          />
        </div>

        <div className="flex items-center gap-1.5">
          {['Semua', 'TUNAI', 'QRIS', 'TRANSFER'].map((method) => (
            <button
              key={method}
              onClick={() => setSelectedMethod(method)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                selectedMethod === method
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {method}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[11px] tracking-wider">
                <th className="py-3 px-4">No. Nota</th>
                <th className="py-3 px-4">Waktu Transaksi</th>
                <th className="py-3 px-4">Petugas Kasir</th>
                <th className="py-3 px-4">Daftar Barang</th>
                <th className="py-3 px-4">Metode</th>
                <th className="py-3 px-4 text-right">Total Tagihan</th>
                <th className="py-3 px-4 text-center">Cetak</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <FileText className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-700">Tidak ada riwayat transaksi</p>
                    <p className="text-xs text-slate-400">Belum ada data yang cocok dengan kriteria pencarian.</p>
                  </td>
                </tr>
              ) : (
                filtered.map((t) => (
                  <tr
                    key={t.id}
                    onClick={() => onSelectTransaction(t)}
                    className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                  >
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {t.invoiceNumber}
                    </td>
                    <td className="py-3 px-4 text-slate-500">
                      {formatDate(t.timestamp)}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-800">
                      {t.cashierName}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-slate-600 line-clamp-1 max-w-[220px]">
                        {t.items.map((i) => `${i.name} (${i.quantity})`).join(', ')}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                          t.paymentMethod === 'TUNAI'
                            ? 'bg-emerald-100 text-emerald-800'
                            : t.paymentMethod === 'QRIS'
                            ? 'bg-indigo-100 text-indigo-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {t.paymentMethod}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-black text-slate-900 font-['Plus_Jakarta_Sans']">
                      {formatRupiah(t.total)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectTransaction(t);
                        }}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer inline-flex items-center gap-1 text-xs font-semibold"
                        title="Lihat & Cetak Ulang Struk"
                      >
                        <Printer className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Struk</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
