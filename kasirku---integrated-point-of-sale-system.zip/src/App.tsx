/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Product, CartItem, Transaction, UserAccount, StoreSettings, PaymentMethod } from './types';
import { StoreService } from './services/storeService';
import { Header } from './components/Header';
import { DashboardStats } from './components/DashboardStats';
import { POSScreen } from './components/POSScreen';
import { ProductManagement } from './components/ProductManagement';
import { ReportsScreen } from './components/ReportsScreen';
import { TransactionHistoryView } from './components/TransactionHistoryView';
import { PaymentModal } from './components/PaymentModal';
import { ReceiptModal } from './components/ReceiptModal';
import { RoleLoginModal } from './components/RoleLoginModal';
import { SettingsModal } from './components/SettingsModal';
import { generateInvoiceNumber } from './utils/formatters';

export default function App() {
  // Main Data States
  const [products, setProducts] = useState<Product[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [storeSettings, setStoreSettings] = useState<StoreSettings>({
    storeName: 'KasirKu Mart',
    tagline: 'Minimarket & Toko Serba Ada',
    address: 'Jl. Merdeka No. 45, Jakarta Pusat',
    phone: '0812-3456-7890',
    receiptFooterMessage: 'Terima kasih atas kunjungan Anda!\nBarang yang sudah dibeli tidak dapat ditukar.',
    enableTax: false,
    taxRatePercent: 11,
  });

  const [currentUser, setCurrentUser] = useState<UserAccount>(StoreService.getCurrentUser());
  const [allUsers] = useState<UserAccount[]>(StoreService.getAllUsers());
  const [serverOnline, setServerOnline] = useState<boolean>(true);

  // View States
  const [activeTab, setActiveTab] = useState<'kasir' | 'produk' | 'laporan' | 'riwayat'>('kasir');
  const [isStatsCollapsed, setIsStatsCollapsed] = useState<boolean>(false);

  // Cart State
  const [cart, setCart] = useState<CartItem[]>([]);

  // Modals
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);
  const [activeReceiptTransaction, setActiveReceiptTransaction] = useState<Transaction | null>(null);
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  // Checkout totals buffer
  const [checkoutData, setCheckoutData] = useState<{ discount: number; tax: number; total: number }>({
    discount: 0,
    tax: 0,
    total: 0,
  });

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Load Initial Data
  const loadData = useCallback(async () => {
    try {
      const [prods, txs, settings] = await Promise.all([
        StoreService.loadProducts(),
        StoreService.loadTransactions(),
        StoreService.loadSettings(),
      ]);
      setProducts(prods);
      setTransactions(txs);
      setStoreSettings(settings);

      // Ping server health
      const res = await fetch('/api/status').catch(() => null);
      setServerOnline(Boolean(res && res.ok));
    } catch (e) {
      console.error('Error loading data:', e);
    }
  }, []);

  useEffect(() => {
    loadData();
    const unsubscribe = StoreService.subscribe(() => {
      loadData();
    });
    return () => unsubscribe();
  }, [loadData]);

  // Cart Actions
  const handleAddToCart = (product: Product) => {
    if (product.stock <= 0) {
      showToast(`Stok ${product.name} telah habis!`);
      return;
    }

    setCart((prevCart) => {
      const existing = prevCart.find((i) => i.product.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) {
          showToast(`Stok ${product.name} tersisa ${product.stock}`);
          return prevCart;
        }
        return prevCart.map((i) =>
          i.product.id === product.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      } else {
        return [...prevCart, { product, quantity: 1 }];
      }
    });
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(productId);
      return;
    }

    const prod = products.find((p) => p.id === productId);
    if (prod && quantity > prod.stock) {
      showToast(`Maksimal stok tersedia: ${prod.stock}`);
      quantity = prod.stock;
    }

    setCart((prev) =>
      prev.map((i) => (i.product.id === productId ? { ...i, quantity } : i))
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCart((prev) => prev.filter((i) => i.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Checkout & Payment
  const handleProceedToPayment = (discountAmount: number, taxAmount: number) => {
    const rawSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    const calculatedTotal = Math.max(0, rawSubtotal - discountAmount) + taxAmount;

    setCheckoutData({
      discount: discountAmount,
      tax: taxAmount,
      total: calculatedTotal,
    });
    setIsPaymentModalOpen(true);
  };

  const handleCompletePayment = async (
    paymentMethod: PaymentMethod,
    amountPaid: number,
    change: number
  ) => {
    const rawSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    const invoiceNumber = generateInvoiceNumber(transactions.length + 1);

    const transactionPayload: Omit<Transaction, 'id'> = {
      invoiceNumber,
      timestamp: new Date().toISOString(),
      items: cart.map((item) => ({
        productId: item.product.id,
        name: item.product.name,
        price: item.product.price,
        cost: item.product.cost || Math.round(item.product.price * 0.75),
        quantity: item.quantity,
        unit: item.product.unit,
        subtotal: item.product.price * item.quantity,
      })),
      subtotal: rawSubtotal,
      discount: checkoutData.discount,
      tax: checkoutData.tax,
      total: checkoutData.total,
      paymentMethod,
      amountPaid,
      change,
      cashierName: currentUser.name,
      cashierRole: currentUser.role,
    };

    try {
      const savedTrx = await StoreService.recordTransaction(transactionPayload);
      setIsPaymentModalOpen(false);
      setCart([]);
      setActiveReceiptTransaction(savedTrx);
      setIsReceiptModalOpen(true);
      showToast(`Transaksi ${savedTrx.invoiceNumber} berhasil disimpan!`);
    } catch (e) {
      console.error('Failed to complete transaction', e);
      showToast('Gagal memproses transaksi.');
    }
  };

  // Product Operations
  const handleSaveProduct = async (prodData: Partial<Product> & { name: string; price: number }) => {
    await StoreService.saveProduct(prodData);
    showToast('Produk berhasil disimpan!');
  };

  const handleDeleteProduct = async (id: string) => {
    await StoreService.deleteProduct(id);
    showToast('Produk berhasil dihapus!');
  };

  const handleRestockProduct = async (id: string, additionalQty: number) => {
    await StoreService.restockProduct(id, additionalQty);
    showToast(`Stok berhasil ditambahkan (+${additionalQty})!`);
  };

  // Switch Role
  const handleSelectUser = (user: UserAccount) => {
    setCurrentUser(user);
    StoreService.setCurrentUser(user);
    showToast(`Login sebagai ${user.name} (${user.role.toUpperCase()})`);
  };

  // Save Settings
  const handleSaveSettings = async (newSettings: StoreSettings) => {
    await StoreService.saveSettings(newSettings);
    setStoreSettings(newSettings);
    showToast('Pengaturan toko diperbarui!');
  };

  // Reset Demo
  const handleResetDemo = async () => {
    if (window.confirm('Reset database ke data awal demo? Semua perubahan akan dikembalikan ke data default.')) {
      await StoreService.resetDemo();
      setCart([]);
      await loadData();
      showToast('Data demo berhasil di-reset!');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-['Plus_Jakarta_Sans'] selection:bg-emerald-500 selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white font-semibold text-xs sm:text-sm px-4 py-2.5 rounded-full shadow-2xl border border-slate-700 animate-in fade-in slide-in-from-top-4 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Header */}
      <Header
        currentUser={currentUser}
        storeSettings={storeSettings}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenRoleModal={() => setIsRoleModalOpen(true)}
        onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
        onResetDemo={handleResetDemo}
        serverOnline={serverOnline}
      />

      {/* Main Workspace Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5">
        {/* Dashboard 4-card stats (Always available or collapsible) */}
        <DashboardStats
          products={products}
          transactions={transactions}
          isCollapsed={isStatsCollapsed}
          onToggleCollapse={() => setIsStatsCollapsed(!isStatsCollapsed)}
        />

        {/* Tab 1: POS Kasir */}
        {activeTab === 'kasir' && (
          <POSScreen
            products={products}
            cart={cart}
            storeSettings={storeSettings}
            onAddToCart={handleAddToCart}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveItem={handleRemoveItem}
            onClearCart={handleClearCart}
            onProceedToPayment={handleProceedToPayment}
          />
        )}

        {/* Tab 2: Manajemen Produk & Stok */}
        {activeTab === 'produk' && (
          <ProductManagement
            products={products}
            userRole={currentUser.role}
            onSaveProduct={handleSaveProduct}
            onDeleteProduct={handleDeleteProduct}
            onRestockProduct={handleRestockProduct}
            onRequestAdminAccess={() => setIsRoleModalOpen(true)}
          />
        )}

        {/* Tab 3: Laporan Penjualan */}
        {activeTab === 'laporan' && (
          <ReportsScreen
            transactions={transactions}
            products={products}
            userRole={currentUser.role}
            onViewTransactionDetail={(trx) => {
              setActiveReceiptTransaction(trx);
              setIsReceiptModalOpen(true);
            }}
          />
        )}

        {/* Tab 4: Riwayat Transaksi */}
        {activeTab === 'riwayat' && (
          <TransactionHistoryView
            transactions={transactions}
            onSelectTransaction={(trx) => {
              setActiveReceiptTransaction(trx);
              setIsReceiptModalOpen(true);
            }}
          />
        )}
      </main>

      {/* Payment Processing Modal */}
      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        totalAmount={checkoutData.total}
        onCompletePayment={handleCompletePayment}
      />

      {/* Receipt Modal (Thermal Print) */}
      <ReceiptModal
        isOpen={isReceiptModalOpen}
        transaction={activeReceiptTransaction}
        storeSettings={storeSettings}
        onClose={() => setIsReceiptModalOpen(false)}
        onNewTransaction={() => {
          setIsReceiptModalOpen(false);
          setActiveTab('kasir');
        }}
      />

      {/* Role / User Switch Modal */}
      <RoleLoginModal
        isOpen={isRoleModalOpen}
        currentUser={currentUser}
        allUsers={allUsers}
        onClose={() => setIsRoleModalOpen(false)}
        onSelectUser={handleSelectUser}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        settings={storeSettings}
        onClose={() => setIsSettingsModalOpen(false)}
        onSaveSettings={handleSaveSettings}
        onResetDemo={handleResetDemo}
      />
    </div>
  );
}
